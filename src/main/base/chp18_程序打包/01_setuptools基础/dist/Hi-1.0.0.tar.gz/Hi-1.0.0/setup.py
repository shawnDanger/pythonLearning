from setuptools import setup
# 安装
setup(name='Hi',
      version='1.0.0',
      description='一个简单样例',
      author='shawn dang',
      requires=['hi'])
# 执行python setup.py install命令安装
